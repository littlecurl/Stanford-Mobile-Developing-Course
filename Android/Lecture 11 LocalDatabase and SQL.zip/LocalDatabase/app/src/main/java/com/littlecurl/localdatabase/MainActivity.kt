package com.littlecurl.localdatabase

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    private val DATABASE_NAME = "babynames"
    private val START_YEAR = 1880
    private val END_YEAR = 2010
    private val MAX_RANKE = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 注意下面的坐标设置一定要设置对，我就是设置了注释的那一行，找了半天Bug
        graph_view.title = "custom title"
        graph_view.viewport.setMinX(START_YEAR.toDouble())
        //graph_view.viewport.setMaxX(START_YEAR.toDouble())
        graph_view.viewport.setMaxX(END_YEAR.toDouble())
        graph_view.viewport.setMinY(0.0)
        graph_view.viewport.setMaxY(MAX_RANKE.toDouble())
    }

    fun searchClick(view: View){
        doQuery()
    }

    private fun doQuery() {
        val name = name_field.text.toString()
        val sex = if (sex_switch.isChecked) "F" else "M"

        val db = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE, null)
        // 注意下面变量需要用单引号引住，否则会报如下错误
        // Caused by: android.database.sqlite.SQLiteException:
        // no such column: Martin (code 1): , while compiling:
        // SELECT year,rank FROM ranks WHERE NAME = Martin AND sex = M
        val query = "SELECT year,rank FROM ranks WHERE NAME = '$name' AND sex = '$sex'"
        // 解决数据必须是ASC的BUG
        // 其实没有必要使用sortedMap，
        // 直接用SQL语句就能解决，ORDER BY 默认是ASC
//        val query = "SELECT year,rank FROM ranks WHERE NAME = '$name' AND sex = '$sex' ORDER BY year"
        // 还有其他功能可以用SQL实现，比如查询排名前5的
        //val query = "SELECT name FROM cities WHERE NAME LIKE 'K%' LIMIT 5"
        val cursor = db.rawQuery(query, null)
        var sortedMap = sortedMapOf<Double,Double>()
        while (cursor.moveToNext()) {
            // 注意下面的是cursor.getInt(cursor.getColumnIndex())
            // 我一开始忘记了getInt()，导致查不出来东西
            val year = cursor.getInt(cursor.getColumnIndex("year"))
            var rank = cursor.getInt(cursor.getColumnIndex("rank"))
            // rank = MAX_RANKE - rank
            sortedMap.put(year.toDouble(),rank.toDouble())

            Log.d("Tag","name = $name, year = $year, rank = $rank")
        }
        // 注意记得关闭游标
        cursor.close()

        val maxPoints = 20
        val series = LineGraphSeries<DataPoint>()
        // kotlin 代码 foreach 一个 map 的方法
        for ((year,rank) in sortedMap) {
            // 注意下面是appendData(DataPoint(,),,)
            series.appendData(DataPoint(year.toDouble(),rank.toDouble()),false,maxPoints)
        }
        // 注意需要提前清空一下视图
        graph_view.removeAllSeries()
        graph_view.addSeries(series)
    }

    fun createClick(view: View){
        Log.d("Tag","Clicked create")
        if(!getDatabasePath("babynames").exists()) {
            importDatabase("babynames")
        }
    }

    fun deleteClick(view: View){
        Log.d("Tag","Clicked delete")
    }

    // 纯手工导入数据
    private fun importDatabase(dbName: String){
        val db = openOrCreateDatabase(dbName, Context.MODE_PRIVATE,null)
        val resId = resources.getIdentifier(dbName,"raw",packageName)
        val scan = Scanner(resources.openRawResource(resId))

        var sql = ""
        while (scan.hasNextLine()){
            val line = scan.nextLine()
            if (line.trim().startsWith("--"))
                continue
            sql += "$line\n"
            if (sql.trim().endsWith(";")) {
                db.execSQL(sql)
                sql = ""
            }
        }
    }

}
