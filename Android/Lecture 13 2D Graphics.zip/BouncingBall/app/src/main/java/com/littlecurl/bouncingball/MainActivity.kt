package com.littlecurl.bouncingball

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // 点击一下，移动一下
    /*
    fun moveClicked(view: View) {
        myView.move()
    }
    */

    // 连续移动
    fun moveClicked(view: View) {
        val t = Thread{
            animationLoop()
        }
        t.start()
    }
    private fun animationLoop() {
        while (true) {
//            myView.move()
            myView.moveBall()
            Thread.sleep(50)
        }
    }


}
