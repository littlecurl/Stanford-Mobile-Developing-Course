package com.littlecurl.restful

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.daimajia.androidanimations.library.Techniques
import com.daimajia.androidanimations.library.YoYo
import com.koushikdutta.ion.Ion
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // get joke Button
    fun getJokeClicked(view: View){
        Ion.with(this)
            .load("http://api.icndb.com/jokes/random")
            .asString()
            .setCallback {
                    _, result ->
                Log.d("Tag","The JSON Data is here:\n $result")
                proccesJokeJSONData(result)
            }

        // 炫酷的控件动态效果
        YoYo.with(Techniques.Tada)
            .duration(700)
            .repeat(5)
            .playOn(findViewById(R.id.getJoke))
    }

    private fun proccesJokeJSONData(result: String){
        val json = JSONObject(result)
        val obj = json.getJSONObject("value")
        val joke = obj.getString("joke")
        textView_joke.text = joke
    }


    // get cat Button
    fun getRandomCatClicked(view: View){
        Ion.with(this)
            .load("https://api.thecatapi.com/api/images/get?format=json&size=med&results_per_page=6")
            .asString()
            .setCallback {
                    _, result ->
                Log.d("Tag","The JSON Data is here:\n $result")
                proccesCatJSONData(result)
                Log.d("Tag","Load Success!")
            }
    }

    private fun proccesCatJSONData(result: String){
        // 第一版代码
        /*
        val json = JSONObject("{\"images\":$result}")
        val imageArray = json.getJSONArray("images")
        val firstImage = imageArray.getJSONObject(0)
        val url = firstImage.getString("url")
        */
        // 第二版代码,只取得第一张图片
        /*
        val url = JSONObject("{\"images\":$result}")
                .getJSONArray("images")
                .getJSONObject(0)
                .getString("url")
        Picasso.get()
            .load(url)
            .into(imageView_cat)
       */
        // 第三版代码，Dynamic UI

        val array = JSONObject("{\"images\":$result}")
                        .getJSONArray("images")

        // 先清除网格布局中的内容
        grid.removeAllViews()
        for (i in 0 until (array.length()-1)) {
            val url = array.getJSONObject(i).getString("url")
            val imageView = ImageView(this)
            imageView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            grid.addView(imageView)
            Picasso.get()
                .load(url)
                .into(imageView)
        }

    }
}
