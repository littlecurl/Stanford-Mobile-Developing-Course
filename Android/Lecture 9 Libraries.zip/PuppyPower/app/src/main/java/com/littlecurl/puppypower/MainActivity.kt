package com.littlecurl.puppypower

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import com.daimajia.androidanimations.library.Techniques
import com.daimajia.androidanimations.library.YoYo
import com.koushikdutta.ion.Ion
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    // companion object like static
    companion object {
        val WEBSITE = "https://www.martystepp.com/dogs"
        val LIST_OF_FILE = "files.txt"
    }


    private lateinit var allImageName : List<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /**
         * 1、单纯的获取图片，图片链接必须支持外链，否则无法获取
         */
/*
        Picasso.get()
            .load("$WEBSITE/$pup")
            .resize(200, 200)
            .rotate(90f)
            .into(photo_image)
*/
        /**
         * 3、okhttp获取动态图片名称列表文件，而不是硬编码entity=@array/..填充到spinner
         */
        Ion.with(this)
            .load("$WEBSITE/$LIST_OF_FILE")
            .asString()
            .setCallback{
                    ex, result ->
                Log.d("Marty","$result")

                allImageName = result.split("\n")
                puppy_spinner.adapter = ArrayAdapter<String>(
                    this, android.R.layout.simple_list_item_1, allImageName
                )
                show_button.isEnabled = true
                // Attention 这里的CallBack函数，由于网络延迟，会有一个执行时间
            }
        // 如果这里有代码，这里的代码会先于回调函数执行，这就是所谓的异步
        // Log.d("Tag","something")

    }

    /**
     * 2、响应按钮，Spinner下拉事件，并填充图片
     */
    fun onClickShow(view: View) {
        // 使用网络获取ImageName的时候就不能再使用数组获取值了
        /**
        val pups = resources.getStringArray(R.array.puppy_images)
        val index = puppy_spinner.selectedItemPosition
        val pup = pups[index]
        */
        val index = puppy_spinner.selectedItemPosition
        val pup = allImageName[index]

        Picasso.get()
            .load("$WEBSITE/$pup")
            .resize(600, 600)
            .into(photo_image)

        // 炫酷的控件动态效果
        YoYo.with(Techniques.Tada)
            .duration(700)
            .repeat(5)
            .playOn(findViewById(R.id.show_button))

    }

}
