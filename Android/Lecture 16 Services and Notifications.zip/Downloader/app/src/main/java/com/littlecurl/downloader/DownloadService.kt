package com.littlecurl.downloader

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.util.Log
import android.os.Build
import android.widget.Toast


class DownloadService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // TODO
        if (intent != null) {
            // 加上action后，可以进行按条件执行服务
            if (intent.action == "download") {
                val url = intent.getStringExtra("url")
                Log.d("DownloadService", "They want me to download this url: $url ")

                // 下载文件，返回文件名
                // 这里调用了downloadFake方法，并不会真的下载文件

                /**
                 * 第一版代码
                 * 线程进行操作，下载任务会阻塞主线程
                 * 阻塞的意思就是，一次只能下载一个任务
                 * 不能同时下载多个任务
                 */
            /*
                Downloader().downloadFake(url)
            */
                //
                /**
                 * 第二版代码
                 * 每次点击都会开一个线程，但是这样做是错误的
                 * 因为这个线程一旦开启，无法停止
                 */
            /*
                val thread = Thread{
                    Downloader().downloadFake(url)
                }
                thread.start()
            */
                /**
                 * 第三版代码
                 * 每次点击都会开一个线程，下载完成后，发送广播
                 */
                val thread = Thread{
                    doWork(url)
                }
                thread.start()
                /**
                 * 第四版代码
                 * 不可能下载1000个任务就开1000个线程吧
                 * 所以需要线程池
                 * 但是，在这节课，老师没有给出实现
                 */


            } else if(intent.action == "bark"){
                Log.d("DownloadService", "ruff")
            }
        }
        // START_STICKY表示保持运行
        return START_STICKY
    }

    // 开启线程做的事情
    private fun doWork(url:String){
        // 第一件事：下载
        Downloader().downloadFake(url)

        // 第二件事：通知
        makeNotification(url)

        // 第三件事：广播
        val doneIntent = Intent()
        doneIntent.action = "downloadcomplete"
        doneIntent.putExtra("url",url)
        sendBroadcast(doneIntent)
    }

    private fun makeNotification(url: String){
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            // Channel
            val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID,NOTIFICATION_CHANNEL_ID,
                NotificationManager.IMPORTANCE_DEFAULT)
            val manager = getSystemService(NOTIFICATION_SERVICE)
                            as NotificationManager
            manager.createNotificationChannel(channel)

            // Builder
            val builder = Notification.Builder(this,NOTIFICATION_CHANNEL_ID)
                .setContentTitle("Download is done")
                .setContentText(url)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.icon_people)

            // 当用户点击这个通知的时候，启动DownloaderActivity
            val intent = Intent(this,DownloaderActivity::class.java)
            intent.action = "downloadcomplete"
            intent.putExtra("url",url)
            val pending = PendingIntent.getActivity(this,0,intent,0)
            builder.setContentIntent(pending)

            val notification = builder.build()
            manager.notify(NOTIFICATION_ID, notification)
//        } else {
////            Toast.makeText(this,"SDK版本低，无法创建小图标",Toast.LENGTH_SHORT).show()
//            Log.d("DownloadService","SDK版本低，无法创建小图标")
//
//        }
    }


    // 此方法用来绑定服务
    // 因为这个程序没有用到绑定模式，所以返回null
    // 要想返回null , 需要在IBinder后面加上 ?
    override fun onBind(intent: Intent?): IBinder? {
        // TODO("Return the communication channel to the service.")
        return null
    }


    companion object{
        private const val NOTIFICATION_CHANNEL_ID = "CS193ADownloadService"
        private const val NOTIFICATION_ID = 1234
    }


}
