package com.littlecurl.downloader

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListAdapter
import android.widget.Toast
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.activity_downloader.*
import java.io.File


class DownloaderActivity : AppCompatActivity() {

    private var files : List<String> = ArrayList()
    private val downloadReceiver = DownloadReceiver()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloader)

        // 确保我们有保存文件的权限
//        askPermission()

        /**
         * 当点击通知图标，进入Activity时
         */
        if(intent != null){
            val url = intent.getStringExtra("url")
            Toast.makeText(this,"$url 已经下载完成",Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this,"以正常方式启动Activity",Toast.LENGTH_SHORT).show()
        }

        // 注册广播,根据Intent的action进行过滤
        val filter = IntentFilter()
        filter.addAction("downloadcomplete")

        registerReceiver(downloadReceiver, filter)

        // 监听ListView的每一个Item的点击事件
        list_of_links.setOnItemClickListener{
            _, _, index, _ ->
            // 根据点击的Item索引，从ArrayList中获取文字
            val fileName = files[index]
            // 根据地址栏手动指定的text，获取当前路径的父路径
            val folder = File(the_url.text.toString()).parent
            // 调用方法，下载文件
            downloadURL("$folder/$fileName")
        }
    }

    override fun onDestroy() {
        Log.i("DownloaderActivity", "关闭注册广播");
        unregisterReceiver(downloadReceiver)
        super.onDestroy()
    }

    // Go 按钮点击事件响应
    // 填充ListView
    fun getListClick(view: View){
        // 从地址栏输入框获取url地址
        val webPageURL = the_url.text.toString()
        // 使用开源库Ion，根据url进行下载
        Ion.with(this)
            .load(webPageURL)
            .asString()
            .setCallback{
                _, text ->
                // 切割下载回调返回值text 赋值给一个ArrayList： files
                files = text.split("\n")
                // 以字符串数组的方式，借助adapter，将内容填充到ListView中
                list_of_links.adapter = ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,files.toTypedArray()) as ListAdapter?
            }
    }

    // 点击每一个Item时候，会触发此方法
    // 从给定的URL地址下载文件
    private fun downloadURL(url: String){
        val fake = fakebox.isChecked
        val delayMS = Integer.valueOf(delayedit.text.toString())
        Toast.makeText(this, "Downloading $url ...", Toast.LENGTH_SHORT).show()
        Log.d("DownloaderActivity", "Initiate download of $url ...")

        // TODO 使用service下载
        val intent = Intent(this, DownloadService::class.java)
        // action 在今天这个项目里可有可无
        // 加上之后，在服务那里就可以判断一下了
        intent.action = "download"
        intent.putExtra("url", url)
        startService(intent)

    }

    private inner class DownloadReceiver : BroadcastReceiver(){

        // 这里的intent: Intent 中的Intent后面没有?
        override fun onReceive(context: Context?, intent: Intent) {
            //TODO
            val url = intent.getStringExtra("url")
            Log.d("DownloadReceiver", "this url is done: $url")
            Toast.makeText(this@DownloaderActivity, "done downloading $url", Toast.LENGTH_SHORT).show()
        }
    }



}
