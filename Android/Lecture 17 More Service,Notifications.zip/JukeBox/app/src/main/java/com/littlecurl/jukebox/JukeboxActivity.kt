package com.littlecurl.jukebox

import android.content.Intent
import android.media.MediaPlayer
import android.os.*
import android.support.v7.app.AppCompatActivity
import android.view.*
import kotlinx.android.synthetic.main.activity_jukebox.*


class JukeboxActivity : AppCompatActivity() {

//    private lateinit var songs: Array<String>
//    private var media: MediaPlayer? = null
//    private var index = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jukebox)
//        songs = resources.getStringArray(R.array.song_titles)
        song_list.setOnItemClickListener { _, _, index, _ ->
            playSongAtIndex(index)
        }
    }
    private fun playSongAtIndex(index: Int) {
        val intent = Intent(this, JukeboxService::class.java)
        intent.action = JukeboxService.PLAY_INDEX_ACTION
        intent.putExtra("index", index)
        startService(intent)
    }

    private fun doIntent(action: String) {
        val intent = Intent(this, JukeboxService::class.java)
        intent.action = action
        startService(intent)
    }

    fun onClickPlay(view: View) {
        doIntent(JukeboxService.PLAY_ACTION)
    }

    fun onClickNextTrack(view: View) {
        doIntent(JukeboxService.NEXT_TRACK_ACTION)
    }

    fun onClickStop(view: View) {
        doIntent(JukeboxService.STOP_ACTION)
    }

}

