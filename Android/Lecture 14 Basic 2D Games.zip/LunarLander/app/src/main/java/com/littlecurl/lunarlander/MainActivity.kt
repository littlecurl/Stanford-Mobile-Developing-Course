package com.littlecurl.lunarlander

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }


    fun playClick(view: View){
        mycanvas.startGame()
    }

    fun stopClick(view: View){
        mycanvas.stopGame()
    }

    fun replayClick(view: View){
        // 经典的代码。目前我知识水平有限，除了这个找不到更好的方法了。
        val intent = intent
        finish()
        startActivity(intent)
    }

}
