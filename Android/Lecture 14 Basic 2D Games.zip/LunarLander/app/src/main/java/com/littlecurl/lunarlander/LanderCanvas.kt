package com.littlecurl.lunarlander

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.AttributeSet
import android.view.MotionEvent
import stanford.androidlib.graphics.*
import java.util.*

class LanderCanvas(context: Context, attrs: AttributeSet)
    : GCanvas(context, attrs) {

    // static constants，share value, not copy anywhere
    companion object {
        private const val FRAMES_PER_SECOND = 30

        private const val MAX_SAFE_LANDING_VELOCITY = 7.0f

        private const val ASTEROID_VELOCITY = -12.0f

        private const val GRAVITY_ACCELERATION = .5f

        private const val THRUST_ACCELERATION = -.3f

        // 小行星大小，及移动速度
        private val ASTEROID_SIZE = 20f
        private val ASTEROID_DX = 12f
    }

    // private fields
//    var rocket: GSprite? = null
    private lateinit var rocket: GSprite
    private lateinit var moonSurface: GSprite
    private lateinit var rocketImage: Bitmap
    private var rocketImageThrust = ArrayList<Bitmap>()




    override fun init() {
//        GSprite.setDebug(true)
        backgroundColor = GColor.BLACK

        //第一版代码,直接往画布中添加
        /*
        val rect = GRect(0f,0f,100f,100f)
        rect.fillColor = GColor.RED
        add(rect)
        */

        //第二版代码，使用GSprite添加,这样才能使用GSprite的一些属性，比如速度，加速度
        /*
        val rect = GRect(0f,0f,100f,100f)
        rect.fillColor = GColor.RED
        val rocket = GSprite(rect)
        add(rocket)
        */
        //第三版代码，添加速度，并更新，使之移动
        /*
        val rect = GRect(0f,0f,100f,100f)
        rect.fillColor = GColor.RED
        val rocket = GSprite(rect)
        rocket.velocityY = 10f
        add(rocket)
        rocket.update()
        */
        //第四版代码，控制刷新的频率，fps;并且让rocket成为lateinit var,以便再其他方法中使用
        /*
        val rect = GRect(0f,0f,100f,100f)
        rect.fillColor = GColor.RED
        rocket = GSprite(rect)
        rocket.velocityY = 10f
        add(rocket)
        animate(FRAMES_PER_SECOND){
            // 独立成方法,方便阅读
            tick()
        }
        */
        //第五版代码，绘制Bitmap，并赋予startGame，stopGame两个按钮功能
        /*
        val rocketImage = BitmapFactory.decodeResource(resources,R.drawable.rocket)
        rocket = GSprite(rocketImage)
        rocket.accelerationY = GRAVITY_ACCELERATION
        add(rocket)
        */
        //第六版代码，按比例缩放图片以适应不同的屏幕
        /*
        var rocketImage = BitmapFactory.decodeResource(resources,R.drawable.rocket)
        rocketImage = rocketImage.scaleToWidth(this.width/6f)
        rocket = GSprite(rocketImage)
        rocket.accelerationY = GRAVITY_ACCELERATION
        add(rocket)
        */
        //第七版代码，添加月球表面的Bitmap，需要先画月球表面，再画火箭，否则月球表面会覆盖掉火箭
        var moonSurfaceImage = BitmapFactory.decodeResource(resources,R.drawable.moonsurface)
        moonSurfaceImage = moonSurfaceImage.scaleToWidth(this.width.toFloat())
        moonSurface = GSprite(moonSurfaceImage)
        moonSurface.bottomY = height.toFloat()
        //第二版碰撞检测
        moonSurface.collisionMarginTop = moonSurface.height / 4f
        add(moonSurface)

        //第八版的火箭绘制代码
        /*
        var rocketImage = BitmapFactory.decodeResource(resources,R.drawable.rocket)
        rocketImage = rocketImage.scaleToWidth(width/4f)
        rocket = GSprite(rocketImage)
        rocket.accelerationY = GRAVITY_ACCELERATION
        add(rocket)
        */
        //第九版的火箭绘制代码，让rocketImage成为lateinit var，下面的rocketImage就不许要带var了
        // 添加4个ArrayList<Bitmap>类型的rocketImageThrust
        rocketImage = BitmapFactory.decodeResource(resources,R.drawable.rocket)
        rocketImage = rocketImage.scaleToWidth(width/4f)
        rocket = GSprite(rocketImage)
        rocket.accelerationY = GRAVITY_ACCELERATION
        add(rocket)

        for(i in 1 until 4){
            var rocketImageThrustOne = BitmapFactory.decodeResource(resources,R.drawable.rocket+i)
            rocketImageThrustOne = rocketImageThrustOne.scaleToWidth(width/4f)
            rocketImageThrust.add(rocketImageThrustOne)
        }


        //第八版代码，在原先的基础上，加上触摸响应事件
        setOnTouchListener{
            _, event ->
            handleTouchEvent(event)
            true
        }

    }

    private fun handleTouchEvent(event: MotionEvent){
        //不用关x，y；点哪里都行
//        val x = event.x
//        val y = event.y
        if(event.action == MotionEvent.ACTION_DOWN) {
            rocket.accelerationY = THRUST_ACCELERATION
            //第九版代码,按下点火,注意这里是bitmaps，带个s
            rocket.bitmaps = rocketImageThrust
            //控制帧率，防止过快
            rocket.framesPerBitmap = FRAMES_PER_SECOND /3
        } else if (event.action == MotionEvent.ACTION_UP){
            rocket.accelerationY = GRAVITY_ACCELERATION
            //第九版代码,松手熄火
            rocket.bitmap = rocketImage
        }
    }


    private var frame = 0
    private var score = 0
    private val scoreLabel = GLabel()
    private fun tick(){
        rocket.update()
        updateAsteroid()


        if(++frame % 30 == 0) {
            ++score
            showScore(score.toString())
        }
        doCollision()
    }

    private fun showScore(str: String){
        scoreLabel.text = "用时：$str s"
        scoreLabel.color = GColor.RED
        scoreLabel.fontSize = 50f
        scoreLabel.x = width/2f
        scoreLabel.y = height/6f
        add(scoreLabel)
    }

    // 第一版碰撞检测
    /*
    private fun doCollision(){
        if (rocket.collidesWith(moonSurface)){
            rocket.velocityY = 0f
            rocket.accelerationY = 0f
        }
    }
    */
    // 第二版碰撞检测
    // 这里的代码没有变，在init中添加了
    private fun doCollision(){
        if (rocket.collidesWith(moonSurface)){
            if(rocket.velocityY <= MAX_SAFE_LANDING_VELOCITY){
                //you win
                // 这里不能使用Toast
                //Toast.makeText(MainActivity.class,"Your velocity has reached: $MAX_SAFE_LANDING_VELOCITY",Toast.LENGTH_SHORT).show()
                showMessage("SAFE LANDING You Win!",width/6f,height/2f)
            } else {
                // you lose
                showMessage("TOO FAST LANDING You Lose!",width/6f,height/2f)
            }

            rocket.velocityY = 0f
            rocket.accelerationY = 0f
            // 碰撞后，必须停止，否则，因为是animate(FRAMES_PER_SECOND)，会一直刷新
            // 如果是很高的速度碰撞，会先显示一下 You Lose
            // 进而速度设置为0，刷新后，再次执行，会多余显示一下 You Win
            animationStop()
        }

    }

    private fun showMessage(str: String, x: Float, y: Float){
        val message = GLabel(str,x,y)
        message.color = GColor.RED
        message.fontSize = 50f
        add(message)
    }


    private var ticks = 0
    fun startGame() {
        animate(FRAMES_PER_SECOND){
            tick()
        }
    }

    fun stopGame() {
        animationStop()
    }

    // 制作随机小行星
    private fun makeAsteroid() {
        val x = width
        val y = Random().nextInt((height-ASTEROID_SIZE).toInt())
        val asteroidGOval = GOval(x.toFloat(),y.toFloat(),ASTEROID_SIZE,ASTEROID_SIZE)
        // 必须是形状设置颜色，而不是下面的asteroid对象设置颜色
        asteroidGOval.fillColor = GColor.GRAY
        add(asteroidGOval)
    }

    // 实现小行星左移
    private fun updateAsteroid() {
        ticks++
        if (ticks == 30){
            makeAsteroid()
            ticks = 0
        }

        for (shape in this) {
            if (shape != rocket && shape != moonSurface && shape != rocketImageThrust && shape != scoreLabel) {
                // 向左走，需要width - ASTEROID_DX
                shape.moveBy(-ASTEROID_DX, 0f)
                if (shape.leftX < 0) {
                    // 清除内存，shape has exited the screen; remove to save memory
                    remove(shape)
                }
            }
        }

    }



}