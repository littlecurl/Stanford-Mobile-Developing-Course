package com.littlecurl.stanforddevelopandroidkotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class MainActivity : AppCompatActivity() {

    private val wordToDefn = HashMap<String, String>()
    private val words = ArrayList<String>()
    private val defns = ArrayList<String>()
    // later to init, just define
    private lateinit var myAdapter: ArrayAdapter<String>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // must first readDirectoryFile then setupList, otherwise it will be crash!
        readDirectoryFile()
        setupList()

        definitions_list.setOnItemClickListener{
            _, _, index, _ ->
            // TODO
            defns.removeAt(index)
            myAdapter.notifyDataSetChanged()
        }


    }

    private fun readDirectoryFile() {
        val reader = Scanner(resources.openRawResource(R.raw.greword))
        while (reader.hasNextLine()){
            val line = reader.nextLine()
            Log.d("[Tag is here]","the line is $line")
            val pieces = line.split("\t")
            words.add(pieces[0])
            wordToDefn.put(pieces[0], pieces[1])
        }
    }


    private fun setupList(){
        val rand = Random()
        val index = rand.nextInt(words.size)
        val word = words[index]
        // the_word is the id of a TextView widget
        the_word.text = word

        defns.clear()
        defns.add(wordToDefn[word]!!)
        words.shuffle()
        for (otherWord in words.subList(0, 5)){
            if (otherWord == word || defns.size == 5){
                continue
            }
            defns.add(wordToDefn[otherWord]!!)
        }
        defns.shuffle()
        // attention the layout resource has a prefix 'android.', not only 'R'
        myAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,defns)
        definitions_list.adapter = myAdapter
    }



}
