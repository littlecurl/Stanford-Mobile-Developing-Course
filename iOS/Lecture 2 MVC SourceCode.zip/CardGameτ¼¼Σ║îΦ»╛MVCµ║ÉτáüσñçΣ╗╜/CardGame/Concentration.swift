//
//  Concentration.swift
//  CardGame
//
//  Created by mac123 on 2019/3/30.
//  Copyright © 2019年 mac123. All rights reserved.
//


/* API is here */

import Foundation

class Concentration {
//  var cards: Array<Card>()
    var cards = [Card]()
    
    var indexOfOneAndOnlyFaceUpCard: Int?
    
    func chooseCard(at index: Int) {
//        if cards[index].isFaceUp {
//            cards[index].isFaceUp = false
//        } else {
//            cards[index].isFaceUp = true
//        }
        if !cards[index].isMatched {
            if let matchIndex = indexOfOneAndOnlyFaceUpCard, matchIndex != index {
//            if cards[matchIndex].identifier == cards[index] {//Binary operator '==' cannot be applied to operands of type 'Int' and 'Card'
                if cards[matchIndex].identifier == cards[index].identifier {
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                }
                cards[index].isFaceUp = true
                indexOfOneAndOnlyFaceUpCard = nil
            }else {
                for flipDownIndex in cards.indices {
                    cards[flipDownIndex].isFaceUp = false
                }
                cards[index].isFaceUp = true
                indexOfOneAndOnlyFaceUpCard = index
            }
        }
    }
    
    init(numberOfPairsOfCards: Int){
        for _ in 1...numberOfPairsOfCards{
            let card = Card()
//            let matchingCard = card // 结构体值传递
//            cards.append(card)
//            cards.append(card)
            cards += [card, card]
            
        }
        // TODO: Shuffle the cards
        
    }
    
}
