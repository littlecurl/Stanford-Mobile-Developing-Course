//
//  Card.swift
//  CardGame
//
//  Created by mac123 on 2019/3/30.
//  Copyright © 2019年 mac123. All rights reserved.
//

/* Model is here */

import Foundation
/*
 结构体 和 类 的两个区别
 一、结构体没有继承
 二、***
    结构体 是 值类型  ，深复制 ， 连带内容一块复制
    类    是 引用类型 ，浅复制 ， 只复制指针地址
    iOS中属于结构体的有：
        Array、int、String、dictionary......
        Swift对于值类型的处理方式是：写时复制 copy-on-write
 
 */
struct Card {
    var isFaceUp = false
    var isMatched = false
    var identifier: Int
    
    static var identifierFactory = 0
    
    static func getUniqueIdentifier() -> Int{
        identifierFactory += 1
        return identifierFactory
    }
//    init(identifier: Int){
//        self.identifier = identifier
//    }
    
    init(){
        self.identifier = Card.getUniqueIdentifier()
    }
}
